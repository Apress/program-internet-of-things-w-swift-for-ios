//
//  UIToolbar+BackgroundImage.h
//  MobileMerchant
//
//  Created by Mangesh on 11/02/14.
//
//

#import <UIKit/UIKit.h>

@interface UIToolbar (BackgroundImage)

-(void)setToolbarBack:(NSString*)bgFilename toolbar:(UIToolbar*)toolbar;

@end
