//
//  NSString+stringWithEscapedXMLValue.h
//  ANMobilePaymentLib
//
//  Created by Shiun Hwang on 6/25/11.
//  Copyright 2011 none. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface NSString (stringWithEscapedXMLValue)

+ (NSString *) stringWithEscapedXMLValue:(NSString *)s;
@end
