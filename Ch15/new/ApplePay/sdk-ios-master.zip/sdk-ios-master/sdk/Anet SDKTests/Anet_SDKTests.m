//
//  Anet_SDKTests.m
//  Anet SDKTests
//
//  Created by MMA on 8/30/13.
//  Copyright (c) 2013 MMA. All rights reserved.
//

#import "Anet_SDKTests.h"

@implementation Anet_SDKTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
//    STFail(@"Unit tests are not implemented yet in Anet SDKTests");
}

@end
