//
//  PayViewController.swift
//  ApplePay
//
//  Created by Gheorghe Chesler on 10/26/15.
//  Copyright © 2015 Devatelier. All rights reserved.
//

import Foundation
import Stripe

class PayViewController: UIViewController, STPPaymentCardTextFieldDelegate {
    
    //AHMED: you need to add iboutlet to hook things up to a storyboard
    //AHMED: they swithced to ?
    @IBOutlet var payButton: UIButton?
    @IBOutlet var paymentTextField: STPPaymentCardTextField?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        paymentTextField = STPPaymentCardTextField()
        paymentTextField?.center = view.center
        view.addSubview(paymentTextField!)
        paymentTextField?.delegate = self
        
        
        /*
        payButton = UIButton()
        payButton.setTitle("Pay", forState:.Normal)
        payButton.addTarget(self, action: "createToken", forControlEvents: .TouchUpInside)
        view.addSubview(payButton)
*/
        //payButton?.enabled = false
    }
    
    func paymentCardTextFieldDidChange(textField: STPPaymentCardTextField) {
        payButton?.enabled = textField.valid
    }
    
    //AHMED: button handlers need IBACTION
    @IBAction func createToken(sender: UIButton) {
        print("Create token in PayViewController")
        let card = paymentTextField?.card! as! STPCard
        Stripe.createTokenWithCard(card) { token, error in
            if let token = token {
                //send token to backend and create charge
                print("token: \(token)")
            }
        }
    }
    
    @IBAction func exit() {
        self.dismissViewControllerAnimated(true, completion: nil)
    }
}