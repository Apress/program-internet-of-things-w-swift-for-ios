//
//  ViewController.swift
//  ApplePay
//
//  Created by Gheorghe Chesler on 10/26/15.
//  Copyright © 2015 Devatelier. All rights reserved.
//

import UIKit
import PassKit
import Stripe

class ViewController: UIViewController, STPPaymentCardTextFieldDelegate, PKPaymentAuthorizationViewControllerDelegate {

//    var payButton: UIButton!
    let SupportedPaymentNetworks = [PKPaymentNetworkVisa, PKPaymentNetworkMasterCard, PKPaymentNetworkAmex]
    let ApplePayMerchantID = "merchant.com.iot.stripe"
    @IBOutlet var payButton: UIButton?
    @IBOutlet var paymentTextField: STPPaymentCardTextField?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        paymentTextField = STPPaymentCardTextField()
        paymentTextField?.center = view.center
        view.addSubview(paymentTextField!)
        paymentTextField?.delegate = self
        
        payButton?.enabled = PKPaymentAuthorizationViewController.canMakePaymentsUsingNetworks(SupportedPaymentNetworks)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func paymentCardTextFieldDidChange(textField: STPPaymentCardTextField) {
        payButton?.enabled = textField.valid
    }
    
    @IBAction func createToken(sender: UIButton) {
        print("Create token in ViewController: createToken")
        if let card = paymentTextField?.card as? STPCard {
            Stripe.createTokenWithCard(card) { token, error in
                if let token = token {
                    //send token to backend and create charge
                    print("token: \(token)")
                }
            }
        }
        else {
            print("Card was not defined in ViewController")
        }
    }
    func paymentAuthorizationViewController(
        controller:                  PKPaymentAuthorizationViewController,
        didAuthorizePayment payment: PKPayment,
        completion:                  (PKPaymentAuthorizationStatus) -> Void) {
        print("Create token in ViewController: paymentAuthorizationViewController")
        Stripe.createTokenWithPayment(payment) { token, error in
            if let token = token {
                print("Got a valid token")
                //handle token to create charge in backend
                print("token: \(token)")
                completion(.Success)
            } else {
                print("Did not get a valid token")
                completion(.Failure)
            }
        }
    }
    
    @IBAction func payWithApplePay(sender: UIButton) {
        self.applePay(1);
    }
    
    func applePay(price: Double) {
        print("Calling applePay in ViewController")
        
        let item = PKPaymentSummaryItem(label: "New Charge", amount: NSDecimalNumber(double: price))
        let request = PKPaymentRequest()
        request.merchantIdentifier = ApplePayMerchantID
        request.supportedNetworks = SupportedPaymentNetworks
        request.merchantCapabilities = .Capability3DS
        request.countryCode = "US"
        request.currencyCode = "USD"
        request.paymentSummaryItems = [item]
        if Stripe.canSubmitPaymentRequest(request) {
            // Apple Pay is available and the user created a valid credit card record
            let applePayController = PKPaymentAuthorizationViewController(paymentRequest: request)
            applePayController.delegate = self
            presentViewController(applePayController, animated: true, completion: nil)
        } else {
            //default to Stripe's PaymentKit Form
        }
    }
    
    func paymentAuthorizationViewControllerDidFinish(controller: PKPaymentAuthorizationViewController) {
        controller.dismissViewControllerAnimated(true, completion: nil)
    }
    
    @IBAction func exit() {
        self.dismissViewControllerAnimated(true, completion: nil)
    }
}

