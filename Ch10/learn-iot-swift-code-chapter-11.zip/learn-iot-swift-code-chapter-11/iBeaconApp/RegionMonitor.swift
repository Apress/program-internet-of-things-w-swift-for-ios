//
//  RegionMonitor.swift
//  iBeaconApp
//
//  Copyright (c) 2015 mdltorriente. All rights reserved.
//

import CoreLocation

protocol RegionMonitorDelegate: NSObjectProtocol {
    func onBackgroundLocationAccessDisabled()
    func didStartMonitoring()
    func didStopMonitoring()
    func didEnterRegion(region: CLRegion!)
    func didExitRegion(region: CLRegion!)
    func didRangeBeacon(beacon: CLBeacon!, region: CLRegion!)
    func onError(error: NSError)
}


class RegionMonitor: NSObject, CLLocationManagerDelegate {

    var locationManager: CLLocationManager!
    var beaconRegion: CLBeaconRegion?
    var rangedBeacon: CLBeacon! = CLBeacon()
    var pendingMonitorRequest: Bool = false
    
    weak var delegate: RegionMonitorDelegate?
    
    init(delegate: RegionMonitorDelegate) {
        super.init()
        self.delegate = delegate
        self.locationManager = CLLocationManager()
        self.locationManager!.delegate = self
    }
    
    func startMonitoring(beaconRegion: CLBeaconRegion?) {
        println("Start monitoring")
        pendingMonitorRequest = true
        self.beaconRegion = beaconRegion

        switch CLLocationManager.authorizationStatus() {
        case .NotDetermined:
            locationManager.requestAlwaysAuthorization()
        case .Restricted, .Denied, .AuthorizedWhenInUse:
            delegate?.onBackgroundLocationAccessDisabled()
        case .AuthorizedAlways:
            locationManager!.startMonitoringForRegion(beaconRegion)
            pendingMonitorRequest = false
        default:
            break
        }
    }

    func stopMonitoring() {
        println("Stop monitoring")
        pendingMonitorRequest = false
        locationManager.stopRangingBeaconsInRegion(beaconRegion)
        locationManager.stopMonitoringForRegion(beaconRegion)
        locationManager.stopUpdatingLocation()
        beaconRegion = nil
        delegate?.didStopMonitoring()
    }

    // MARK: CLLocationManagerDelegate methods

    func locationManager(manager: CLLocationManager!, didChangeAuthorizationStatus status: CLAuthorizationStatus) {
        println("didChangeAuthorizationStatus \(status)")
        if status == .AuthorizedWhenInUse || status == .AuthorizedAlways {
            if pendingMonitorRequest {
                locationManager!.startMonitoringForRegion(beaconRegion)
                pendingMonitorRequest = false
            }
            locationManager!.startUpdatingLocation()
        }
    }

    func locationManager(manager: CLLocationManager!, didStartMonitoringForRegion region: CLRegion!) {
        println("didStartMonitoringForRegion \(region.identifier)")
        delegate?.didStartMonitoring()
        locationManager.requestStateForRegion(region)
    }
    
    func locationManager(manager: CLLocationManager!, monitoringDidFailForRegion region: CLRegion!, withError error: NSError!) {
        println("monitoringDidFailForRegion - \(error)")
    }
    
    func locationManager(manager: CLLocationManager!, didDetermineState state: CLRegionState, forRegion region: CLRegion!) {
        println("didDetermineState")
        if state == CLRegionState.Inside {
            println(" - entered region \(region.identifier)")
            locationManager.startRangingBeaconsInRegion(beaconRegion)
        } else {
            println(" - exited region \(region.identifier)")
            locationManager.stopRangingBeaconsInRegion(beaconRegion)
        }
    }
    
    func locationManager(manager: CLLocationManager!, didEnterRegion region: CLRegion!) {
        println("didEnterRegion - \(region.identifier)")
        delegate?.didEnterRegion(region)
    }
    
    func locationManager(manager: CLLocationManager!, didExitRegion region: CLRegion!) {
        println("didExitRegion - \(region.identifier)")
        delegate?.didExitRegion(region)
    }
    
    func locationManager(manager: CLLocationManager!, didRangeBeacons beacons: [AnyObject]!, inRegion region: CLBeaconRegion!) {
        println("didRangeBeacons - \(region.identifier)")
        
        if let rangedBeacons = beacons {
            if (beacons.count > 0) {
                if let beacon = rangedBeacons[0] as? CLBeacon {
                    rangedBeacon = beacon
                    delegate?.didRangeBeacon(rangedBeacon, region: region)
                }
            }
        }
    }
    
    func locationManager(manager: CLLocationManager!, rangingBeaconsDidFailForRegion region: CLBeaconRegion!, withError error: NSError!) {
        println("rangingBeaconsDidFailForRegion \(error)")
    }

    func locationManager(manager: CLLocationManager!, didFailWithError error: NSError!) {
        println("didFailWithError \(error)")
        if (error.code == CLError.Denied.rawValue) {
            stopMonitoring()
        }
    }
}
