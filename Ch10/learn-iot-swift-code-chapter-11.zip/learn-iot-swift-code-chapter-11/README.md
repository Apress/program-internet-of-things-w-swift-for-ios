# Learn IoT with Swift #
*Work-in-progress*

## Chapter 11: Building location awareness with iBeacons ##
This is companion code

### Description ###
A simple dual-purpose application that demonstrates how to scan for specific nearby iBeacons, and configure your BLE capable iOS device as an iBeacon transmitter. The app consists of three master scenes: a Home scene, a Region Monitor scene, and a iBeacon scene. The Home scene provides segues to the other scenes, and provides an indicator label that reflects the current Bluetooth ON/OFF state of the device. The Region Monitor scene supports two basic methods for interacting with beacons, region monitoring and ranging. The iBeacon scene allows you to configure your iOS device as an iBeacon transmitter.