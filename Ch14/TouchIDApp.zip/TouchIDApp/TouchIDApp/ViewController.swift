//
//  ViewController.swift
//  TouchIDApp
//
//  Copyright © 2015 mdltorriente. All rights reserved.
//

import UIKit
import LocalAuthentication

class ViewController: UITableViewController {

    @IBOutlet weak var textView: UITextView!

    override func viewDidLoad() {
        super.viewDidLoad()
        textView.text = ""
    }

    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }

    override func tableView(tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "Actions"
    }

    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("AuthenticateCell", forIndexPath: indexPath)
        cell.textLabel?.text = "Authenticate"
        cell.detailTextLabel?.text = "Local Authentication using Touch ID"
        return cell
    }

    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        tableView.deselectRowAtIndexPath(indexPath, animated: true)
        authenticate()
    }

    func authenticate() {
        printMessage("authenticating...")

        let context = LAContext()
        var error: NSError?

        guard context.canEvaluatePolicy(.DeviceOwnerAuthenticationWithBiometrics, error: &error) else {
            printMessage("canEvaluatePolicy failed: \(error!.localizedDescription)")
            return
        }

        // Touch ID is available

        let reason = "Authenticate to login"
        context.evaluatePolicy(.DeviceOwnerAuthentication/*WithBiometrics*/, localizedReason: reason, reply: { (success, error) -> Void in

            if success {
                self.printMessage("Authentication success!")
            } else {
                if let error = error {
                    self.printMessage("Error: \(error.localizedDescription)")
                }
            }
        })
    }

    // MARK: Convenience

    func printMessage(message: String) {
        dispatch_async(dispatch_get_main_queue()) { () -> Void in
            self.textView.text = self.textView.text.stringByAppendingString(message + "\n")
            self.textView.scrollRangeToVisible(NSMakeRange(self.textView.text.characters.count-1, 0))
        }
    }
}

