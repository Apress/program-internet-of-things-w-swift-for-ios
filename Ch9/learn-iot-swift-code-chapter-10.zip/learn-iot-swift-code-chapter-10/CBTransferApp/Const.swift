//
//  Const.swift
//  CBTransferApp
//
//  Copyright (c) 2015 mdltorriente. All rights reserved.
//

let kTransferServiceUUID: String = "3C4F8654-E41B-4696-B5C6-13D06336F22E"
let kTransferCharacteristicUUID: String = "DEB07A07-463E-4A65-BABB-0DA17E4E517A"

let kCentralRoleSegue: String = "CentralRoleSegue"
let kPeripheralRoleSegue: String = "PeripheralRoleSegue"
